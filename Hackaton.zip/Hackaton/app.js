
const btn = document.querySelector(".btns")
const first = document.querySelector(".read")
const books = document.querySelector(".shelf")

btn.addEventListener("click", function(e){
    const id = e.currentTarget.dataset.id;
     const label = first.classList; 
     if(id == label){
       first.classList.add('third');
       second.classList.remove('third')
       second1.classList.remove('third')
       second3.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       second7.classList.remove('third')
       sitting.classList.add('stand')
     }else{
        first.classList.remove('third')
        sitting.classList.remove('stand')
     }

})


const btns = document.querySelector(".btn1")
const second = document.querySelector(".read1")

btns.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second.classList; 
     if(id1 == label1){
       second.classList.add('third')
       first.classList.remove('third');
       second1.classList.remove('third')
       second2.classList.remove('third')
       second3.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       second7.classList.remove('third')
       sitting.classList.add('stand')
     }else{
        second.classList.remove('third')
        sitting.classList.remove('stand')
     }
})


const btn1 = document.querySelector(".btn2")
const second1 = document.querySelector(".read2")

btn1.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second1.classList; 
     if(id1 == label1){
       second1.classList.add('third')
       first.classList.remove('third');
       second.classList.remove('third')
       second2.classList.remove('third')
       second3.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       second7.classList.remove('third')
       sitting.classList.add('stand')
     }else{
        second1.classList.remove('third')
        sitting.classList.remove('stand')
     }
})
// })


const btn2 = document.querySelector(".btn3")
const second2 = document.querySelector(".read3")

btn2.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second2.classList; 
     if(id1 == label1){
       second2.classList.add('third')
       first.classList.remove('third');
       second.classList.remove('third')
       second3.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       second7.classList.remove('third')
       sitting.classList.add('stand')
    // console.log("hell?");
     }else{
        second2.classList.remove('third')
        sitting.classList.remove('stand')
        // console.log("hello");
     }
})

const btn3 = document.querySelector(".btn4")
const second3 = document.querySelector(".read4")

btn3.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second3.classList; 
     if(id1 == label1){
       second3.classList.add('third')
       first.classList.remove('third');
       second2.classList.remove('third')
       second.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       sitting.classList.add('stand')
       second7.classList.remove('third')
     }else{
        second3.classList.remove('third')
        sitting.classList.remove('stand')
        // console.log("hello");
     }
})

const btn4 = document.querySelector(".btn5")
const second4 = document.querySelector(".read5")

btn4.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second4.classList; 
     if(id1 == label1){
       second4.classList.add('third')
       first.classList.remove('third');
       second2.classList.remove('third')
       second.classList.remove('third')
       second3.classList.remove('third')
       second7.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
       sitting.classList.add('stand')
       second7.classList.remove('third')
     }else{
        second4.classList.remove('third')
        sitting.classList.remove('stand')
        // console.log("hello");
     }
})

const btn5 = document.querySelector(".btn6")
const second5 = document.querySelector(".read6")
btn5.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second5.classList; 
     if(id1 == label1){
       second5.classList.add('third')
       first.classList.remove('third');
       second2.classList.remove('third')
       second.classList.remove('third')
       second3.classList.remove('third')
       sitting.classList.add('stand')
     }else{
        second5.classList.remove('third')
         sitting.classList.remove('stand')
        // console.log("hello");
     }
})

const btn6 = document.querySelector(".btn7")
const second6 = document.querySelector(".read7")
const sitting = document.querySelector(".sitting")

btn6.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second6.classList; 
     if(id1 == label1){
       second6.classList.add('third')
       first.classList.remove('third');
       second2.classList.remove('third')
       sitting.classList.add('stand')
       second.classList.remove('third')
       second3.classList.remove('third')
       second4.classList.remove('third')
       second5.classList.remove('third')
       second7.classList.remove('third')
     }else{
        second6.classList.remove('third');
        sitting.classList.remove('stand')
        
        // console.log(sitting);
        // console.log("hello");
     }
})

const btn7 = document.querySelector(".btn8")
const second7 = document.querySelector(".read8")
btn7.addEventListener("click", function(e){
    const id1 = e.currentTarget.dataset.id;
     const label1 = second7.classList; 
     if(id1 == label1){
       second7.classList.add('third')
       first.classList.remove('third');
       sitting.classList.add('stand')
       second2.classList.remove('third')
       second.classList.remove('third')
       second3.classList.remove('third')
       second5.classList.remove('third')
       second6.classList.remove('third')
     }else{
        second7.classList.remove('third')
        sitting.classList.remove('stand')
        // console.log("hello");
     }
})